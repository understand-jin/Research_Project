# Portfolio – HyeJin Lee

This repository hosts my portfolio PDF and a simple web viewer.

- Open the site via **GitHub Pages** after enabling Pages on the `main` branch (root).
- Direct file: [`portfolio_HyeJin.pdf`](./portfolio_HyeJin.pdf)

## How to publish with GitHub Pages
1. Create a new public repository (e.g., `portfolio`).
2. Upload `index.html` and `portfolio_HyeJin.pdf` (and optionally this `README.md`) to the root.
3. Go to **Settings → Pages**.
   - **Source**: Deploy from a branch
   - **Branch**: `main` / **root**
4. Your site will be available at: `https://<username>.github.io/<repo>/`
